

//回退
$('.back').click(function () {
    console.log('back')
    window.history.back()
})